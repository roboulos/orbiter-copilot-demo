module.exports=[7837,(e,o,d)=>{}];

//# sourceMappingURL=4362b__next-internal_server_app_favicon_ico_route_actions_fcf39563.js.map