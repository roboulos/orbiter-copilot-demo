module.exports=[29880,(a,b,c)=>{}];

//# sourceMappingURL=9e3a1_orbiter-copilot-demo__next-internal_server_app__not-found_page_actions_18804b84.js.map