module.exports=[78863,(a,b,c)=>{}];

//# sourceMappingURL=4362b__next-internal_server_app__global-error_page_actions_a6f99037.js.map