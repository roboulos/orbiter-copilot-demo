module.exports=[23680,(a,b,c)=>{}];

//# sourceMappingURL=projects_orbiter-copilot-demo__next-internal_server_app_page_actions_390cae70.js.map