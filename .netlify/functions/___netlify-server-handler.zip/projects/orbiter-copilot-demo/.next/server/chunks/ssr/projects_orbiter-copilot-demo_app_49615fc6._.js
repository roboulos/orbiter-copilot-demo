module.exports=[79100,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},44736,a=>{"use strict";let b={src:a.i(79100).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=projects_orbiter-copilot-demo_app_49615fc6._.js.map