var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/route.js")
R.c("server/chunks/[externals]_next_dist_0849b485._.js")
R.c("server/chunks/61075_40ebb768._.js")
R.c("server/chunks/[root-of-the-server]__ae0eb254._.js")
R.c("server/chunks/9e3a1_orbiter-copilot-demo__next-internal_server_app_api_chat_route_actions_ce2cfd1a.js")
R.m(76876)
module.exports=R.m(76876).exports
