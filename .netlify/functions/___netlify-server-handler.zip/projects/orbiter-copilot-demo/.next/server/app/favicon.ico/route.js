var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_03fe02e0._.js")
R.c("server/chunks/[root-of-the-server]__ae0eb254._.js")
R.c("server/chunks/61075_next_b8246bcd._.js")
R.c("server/chunks/4362b__next-internal_server_app_favicon_ico_route_actions_fcf39563.js")
R.m(19459)
module.exports=R.m(19459).exports
